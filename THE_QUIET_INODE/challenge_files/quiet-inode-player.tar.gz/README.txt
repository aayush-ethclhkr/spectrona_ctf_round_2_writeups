SPECTRONA CTF — THE QUIET INODE
Category: Digital Forensics / Linux
Difficulty: Insane
Mode: Fully offline, file-based
Flag format: SPECTRONA{HEAD_BODY_TAIL} where each section is an uppercase hexadecimal string.

INCIDENT BRIEF
At 02:17 UTC, a Linux workstation used by a university research assistant was found powered off.
The response team received a raw collection of host artifacts. The operator claims the machine was clean;
the evidence timeline disagrees.

Recover the three-part flag. It is not stored as one plaintext value. Correlate artifacts and document
how each part was recovered. The evidence must be investigated offline; no network access is needed.

Rules:
- Work on a copy of the evidence.
- Do not execute recovered binaries or scripts.
- Treat timestamps and exported logs as potentially misleading until correlated.
- The challenge is designed for a Linux environment. Python 3 and Git are available on a standard analyst VM;
  no pip install or network access is required.
- Verify evidence integrity using SHA256SUMS.txt before analysis.

The bundle is an intentionally curated forensic collection, not a bootable disk image.
