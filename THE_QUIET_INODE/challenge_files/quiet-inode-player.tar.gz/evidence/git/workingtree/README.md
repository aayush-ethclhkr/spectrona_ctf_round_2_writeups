Worktree export. Current branch only reflects the surviving state.
