# Renderer working tree

Recovered worktree state. Evidence may survive in Git objects that are no longer referenced by a branch.
