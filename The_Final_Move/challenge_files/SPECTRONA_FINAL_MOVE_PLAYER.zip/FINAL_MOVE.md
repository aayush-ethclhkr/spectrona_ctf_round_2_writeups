# The Final Move

**Category:** Misc  
**Difficulty:** Medium  
**Flag format:** `spectrona{...}`

## Description

A historic chess score has been preserved in a PGN file. The move record is genuine, but the file contains another layer that does not belong to the original game.

Separate the game from the added layer. Use what you recover as a lead, corroborate the sporting connection with public sources,and shhhh
## Attachment

- `final_move.pgn` — a portable game notation file containing the score and annotations.

## Objective

Recover the complete flag from the intended YouTube video's description. Submit it in the exact format `spectrona{...}`.

## Rules

- Use the supplied file and publicly accessible sources.
- Treat the move sequence and annotations as evidence; independently verify important deductions.
- No account access, contacting people, brute force, or intrusive activity is needed.

Good luck. There are two histories in the record. Separate them before you follow the trail.
